"use client"

import { useEffect, useState } from "react"
import { motion } from "framer-motion"
import {
  Smartphone,
  Monitor,
  Cigarette,
  Wine,
  Candy,
  Brain,
  Clock,
  Pill,
  Instagram,
  ArrowLeft,
  CheckCircle,
  Youtube,
  ExternalLink,
  BookOpen,
  Target,
  Quote,
  Sparkles,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"

// Addiction data with detailed information
const addictionsData = {
  porn: {
    name: "Porn Addiction",
    description:
      "Pornography addiction is characterized by compulsive viewing of pornographic material, leading to negative consequences in one's life, relationships, and mental health.",
    icon: Monitor,
    color: "from-red-500 to-pink-500",
    quote: "Recovery is about progression, not perfection.",
    solutions: [
      "Install website blockers on all devices",
      "Join support groups or find an accountability partner",
      "Practice mindfulness and meditation",
      "Identify and avoid triggers",
      "Seek professional therapy if needed",
      "Develop healthy hobbies to replace the habit",
    ],
    youtubeId: "dxtQq0jBncc",
    task: "Avoid all electronic devices for 2 hours today",
  },
  mobile: {
    name: "Mobile Addiction",
    description:
      "Mobile addiction involves excessive smartphone use that interferes with daily life, causing anxiety when separated from the device and neglect of other activities.",
    icon: Smartphone,
    color: "from-blue-500 to-cyan-500",
    quote: "Disconnect to reconnect with what truly matters.",
    solutions: [
      "Set specific times to check your phone",
      "Use apps that track and limit screen time",
      "Turn off non-essential notifications",
      "Keep your phone out of the bedroom",
      "Create phone-free zones in your home",
      "Find alternative activities you enjoy",
    ],
    youtubeId: "Uwl5y6A8YWM",
    task: "Put your phone in another room during meals today",
  },
  drugs: {
    name: "Drug Addiction",
    description:
      "Drug addiction is a chronic disorder characterized by compulsive drug seeking and use despite harmful consequences and changes in the brain.",
    icon: Pill,
    color: "from-purple-500 to-indigo-500",
    quote: "The first step towards getting somewhere is to decide you're not going to stay where you are.",
    solutions: [
      "Seek professional medical help immediately",
      "Consider rehabilitation programs",
      "Join support groups like NA or AA",
      "Build a strong support network",
      "Avoid people and places associated with drug use",
      "Develop healthy coping mechanisms for stress",
    ],
    youtubeId: "C8AHODc6phg",
    task: "Write down three reasons why you want to be drug-free",
  },
  gaming: {
    name: "Gaming Addiction",
    description:
      "Gaming addiction involves excessive and compulsive use of video games that leads to significant impairment in personal, family, social, educational, or occupational functioning.",
    icon: Monitor,
    color: "from-green-500 to-emerald-500",
    quote: "Balance in all things is the key to a fulfilling life.",
    solutions: [
      "Set strict time limits for gaming",
      "Use apps to track and limit gaming time",
      "Find alternative hobbies and activities",
      "Join support groups for gaming addiction",
      "Seek therapy if gaming is affecting your life",
      "Create a balanced daily schedule",
    ],
    youtubeId: "9O4_awEHh1g",
    task: "Replace one hour of gaming with physical activity today",
  },
  "social-media": {
    name: "Social Media Addiction",
    description:
      "Social media addiction involves being overly concerned about social media, driven by an uncontrollable urge to log on and use social media, devoting so much time that it impairs other important life areas.",
    icon: Instagram,
    color: "from-pink-500 to-orange-500",
    quote: "Life is what happens when you're busy scrolling through someone else's.",
    solutions: [
      "Delete social media apps from your phone",
      "Use website blockers during work/study",
      "Set specific times to check social media",
      "Turn off all social media notifications",
      "Find real-world social activities",
      "Practice mindfulness when using technology",
    ],
    youtubeId: "GXdVPLj_pIk",
    task: "Go 24 hours without checking any social media",
  },
  smoking: {
    name: "Smoking",
    description:
      "Smoking addiction is a dependence on tobacco products containing nicotine, characterized by compulsive use despite harmful consequences to health.",
    icon: Cigarette,
    color: "from-gray-500 to-slate-500",
    quote: "Every time you resist a craving, you're one step closer to freedom.",
    solutions: [
      "Consider nicotine replacement therapy",
      "Try prescription medications to reduce cravings",
      "Join a smoking cessation program",
      "Identify and avoid triggers",
      "Practice deep breathing techniques",
      "Exercise regularly to reduce cravings",
    ],
    youtubeId: "9O4_awEHh1g",
    task: "Delay your first cigarette of the day by one hour",
  },
  alcohol: {
    name: "Alcohol",
    description:
      "Alcohol addiction, or alcoholism, is a chronic disease characterized by uncontrolled drinking and preoccupation with alcohol despite its negative consequences.",
    icon: Wine,
    color: "from-amber-500 to-yellow-500",
    quote: "Sobriety delivers everything alcohol promised.",
    solutions: [
      "Seek medical help for safe detoxification",
      "Join Alcoholics Anonymous or similar groups",
      "Consider rehabilitation programs",
      "Build a strong support network",
      "Identify and avoid drinking triggers",
      "Develop healthy stress management techniques",
    ],
    youtubeId: "HUngLgGRJpo",
    task: "Write down how alcohol has negatively impacted your life",
  },
  sugar: {
    name: "Sugar Addiction",
    description:
      "Sugar addiction involves craving and consuming excessive amounts of sugary foods and drinks, leading to negative health consequences and difficulty controlling intake.",
    icon: Candy,
    color: "from-rose-500 to-red-500",
    quote: "Your body is a temple, not a trash can.",
    solutions: [
      "Gradually reduce sugar intake",
      "Read food labels to identify hidden sugars",
      "Eat regular, balanced meals",
      "Stay hydrated with water",
      "Find healthy alternatives to satisfy sweet cravings",
      "Manage stress without using food",
    ],
    youtubeId: "lEXBxijQREo",
    task: "Replace one sugary snack with fruit today",
  },
  overthinking: {
    name: "Overthinking",
    description:
      "Overthinking involves dwelling on problems, situations, or decisions excessively, often leading to anxiety, stress, and difficulty taking action.",
    icon: Brain,
    color: "from-violet-500 to-purple-500",
    quote: "Overthinking is like a rocking chair. It gives you something to do but gets you nowhere.",
    solutions: [
      "Practice mindfulness meditation",
      "Set a time limit for making decisions",
      "Challenge negative thoughts",
      "Keep a thought journal",
      "Exercise regularly to reduce anxiety",
      "Consider cognitive behavioral therapy",
    ],
    youtubeId: "dO1NpT2SSX4",
    task: "When you catch yourself overthinking today, take 5 deep breaths",
  },
  procrastination: {
    name: "Procrastination",
    description:
      "Procrastination is the habit of delaying important tasks, often focusing on less urgent, more enjoyable activities instead, leading to poor performance and increased stress.",
    icon: Clock,
    color: "from-teal-500 to-green-500",
    quote: "The best way to get something done is to begin.",
    solutions: [
      "Break tasks into smaller, manageable steps",
      "Use the Pomodoro Technique (25 min work, 5 min break)",
      "Remove distractions from your environment",
      "Set specific, realistic deadlines",
      "Reward yourself after completing tasks",
      "Address underlying fears or perfectionism",
    ],
    youtubeId: "arj7oStGLkU",
    task: "Complete one task you've been putting off today",
  },
}

export default function AddictionDetailPage({ params }: { params: { id: string } }) {
  const [addiction, setAddiction] = useState<any>(null)

  useEffect(() => {
    // Get addiction data based on ID
    const data = addictionsData[params.id as keyof typeof addictionsData]
    if (data) {
      setAddiction(data)
    }
  }, [params.id])

  if (!addiction) {
    return (
      <div className="container max-w-4xl mx-auto px-4 py-8">
        <p className="text-white/70">Loading...</p>
      </div>
    )
  }

  const IconComponent = addiction.icon

  // Animation variants
  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 },
  }

  return (
    <div className="container max-w-4xl mx-auto px-4 py-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="space-y-8"
      >
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" asChild className="text-white hover:bg-white/10">
            <Link href="/dashboard/explore">
              <ArrowLeft className="h-5 w-5" />
            </Link>
          </Button>
          <div>
            <Badge className={`bg-gradient-to-r ${addiction.color} text-white border-0 mb-2`}>Addiction</Badge>
            <h1 className="text-3xl font-bold text-white">{addiction.name}</h1>
          </div>
        </div>

        {/* Hero Card */}
        <Card className={`overflow-hidden border-0 shadow-xl bg-gradient-to-r ${addiction.color}`}>
          <CardContent className="p-0">
            <div className="relative">
              {/* Background pattern */}
              <div className="absolute inset-0 opacity-10">
                <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
                  <defs>
                    <pattern id="grid" width="10" height="10" patternUnits="userSpaceOnUse">
                      <path d="M 10 0 L 0 0 0 10" fill="none" stroke="white" strokeWidth="0.5" />
                    </pattern>
                  </defs>
                  <rect width="100" height="100" fill="url(#grid)" />
                </svg>
              </div>

              <div className="p-8 md:p-10 relative z-10">
                <div className="flex flex-col md:flex-row gap-8 items-center">
                  <div className="flex-1 space-y-6">
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/20 text-white text-sm font-medium">
                      <BookOpen className="h-4 w-4" />
                      <span>Understanding {addiction.name}</span>
                    </div>

                    <div className="space-y-4">
                      <h2 className="text-2xl md:text-3xl font-bold text-white">What is {addiction.name}?</h2>
                      <p className="text-white/90 text-lg">{addiction.description}</p>
                    </div>
                  </div>

                  <div className="flex items-center justify-center">
                    <div className="w-24 h-24 rounded-full bg-white/20 backdrop-blur-md flex items-center justify-center">
                      <IconComponent className="h-12 w-12 text-white" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Solutions Card */}
          <Card className="border border-white/10 bg-white/5 backdrop-blur-sm shadow-lg overflow-hidden">
            <CardHeader className="pb-3 border-b border-white/10">
              <CardTitle className="flex items-center gap-2 text-white">
                <CheckCircle className="h-5 w-5 text-emerald-500" />
                Solutions
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <motion.ul className="space-y-3" variants={container} initial="hidden" animate="show">
                {addiction.solutions.map((solution: string, index: number) => (
                  <motion.li key={index} variants={item} className="flex items-start gap-3">
                    <div className="w-6 h-6 rounded-full bg-emerald-500/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                      <CheckCircle className="h-4 w-4 text-emerald-500" />
                    </div>
                    <span className="text-white/90">{solution}</span>
                  </motion.li>
                ))}
              </motion.ul>
            </CardContent>
          </Card>

          {/* Quote Card */}
          <Card className="border border-white/10 bg-white/5 backdrop-blur-sm shadow-lg overflow-hidden">
            <CardHeader className="pb-3 border-b border-white/10">
              <CardTitle className="flex items-center gap-2 text-white">
                <Quote className="h-5 w-5 text-pink-500" />
                Motivational Quote
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6 flex items-center">
              <div className="relative">
                <div className="absolute -top-2 -left-2 text-4xl text-pink-500 opacity-30">"</div>
                <div className="absolute -bottom-8 -right-2 text-4xl text-pink-500 opacity-30">"</div>
                <blockquote className="text-xl italic text-white/90 px-6 py-2">{addiction.quote}</blockquote>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Video Card */}
        <Card className="border border-white/10 bg-white/5 backdrop-blur-sm shadow-lg overflow-hidden">
          <CardHeader className="pb-3 border-b border-white/10">
            <CardTitle className="flex items-center gap-2 text-white">
              <Youtube className="h-5 w-5 text-red-500" />
              Helpful Video
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <div className="aspect-video bg-black/30 flex items-center justify-center rounded-md overflow-hidden">
              <div className="flex flex-col items-center gap-4">
                <div className="w-16 h-16 rounded-full bg-red-500/20 flex items-center justify-center">
                  <Youtube className="h-8 w-8 text-red-500" />
                </div>
                <div className="text-center">
                  <p className="text-white/90 font-medium">YouTube Video: {addiction.youtubeId}</p>
                  <p className="text-xs text-white/50 mt-1">
                    (In a real app, this would be an embedded YouTube player)
                  </p>
                </div>
                <Button variant="outline" className="text-white border-white/20 hover:bg-white/10">
                  <ExternalLink className="mr-2 h-4 w-4" />
                  Watch on YouTube
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Task Card */}
        <Card className="border-0 shadow-xl bg-gradient-to-r from-blue-600 to-cyan-600 overflow-hidden">
          <CardContent className="p-0">
            <div className="p-6 md:p-8">
              <div className="flex flex-col md:flex-row items-center gap-6">
                <div className="w-16 h-16 rounded-full bg-white/20 flex items-center justify-center flex-shrink-0">
                  <Target className="h-8 w-8 text-white" />
                </div>
                <div className="space-y-2 text-center md:text-left">
                  <h3 className="text-xl font-bold text-white">Today's Mini Task</h3>
                  <p className="text-white/90 text-lg">{addiction.task}</p>
                </div>
                <Button className="ml-auto bg-white text-blue-600 hover:bg-white/90">
                  <Sparkles className="mr-2 h-4 w-4" />
                  Accept Challenge
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  )
}
