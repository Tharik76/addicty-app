"use client"

import { motion } from "framer-motion"
import Link from "next/link"
import { Smartphone, Monitor, Cigarette, Wine, Candy, Brain, Clock, Pill, Instagram, Search } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { useState } from "react"

// Addiction data
const addictions = [
  {
    id: "porn",
    name: "Porn Addiction",
    description: "Break free from the cycle of pornography addiction.",
    icon: Monitor,
    color: "from-red-500 to-pink-500",
  },
  {
    id: "mobile",
    name: "Mobile Addiction",
    description: "Reduce screen time and reconnect with real life.",
    icon: Smartphone,
    color: "from-blue-500 to-cyan-500",
  },
  {
    id: "drugs",
    name: "Drug Addiction",
    description: "Find support to overcome substance dependency.",
    icon: Pill,
    color: "from-purple-500 to-indigo-500",
  },
  {
    id: "gaming",
    name: "Gaming Addiction",
    description: "Balance gaming with a healthy lifestyle.",
    icon: Monitor,
    color: "from-green-500 to-emerald-500",
  },
  {
    id: "social-media",
    name: "Social Media Addiction",
    description: "Break the endless scrolling habit.",
    icon: Instagram,
    color: "from-pink-500 to-orange-500",
  },
  {
    id: "smoking",
    name: "Smoking",
    description: "Quit smoking and improve your health.",
    icon: Cigarette,
    color: "from-gray-500 to-slate-500",
  },
  {
    id: "alcohol",
    name: "Alcohol",
    description: "Overcome alcohol dependency and regain control.",
    icon: Wine,
    color: "from-amber-500 to-yellow-500",
  },
  {
    id: "sugar",
    name: "Sugar Addiction",
    description: "Reduce sugar intake for better health.",
    icon: Candy,
    color: "from-rose-500 to-red-500",
  },
  {
    id: "overthinking",
    name: "Overthinking",
    description: "Calm your mind and reduce anxiety.",
    icon: Brain,
    color: "from-violet-500 to-purple-500",
  },
  {
    id: "procrastination",
    name: "Procrastination",
    description: "Stop putting things off and boost productivity.",
    icon: Clock,
    color: "from-teal-500 to-green-500",
  },
]

export default function ExplorePage() {
  const [searchTerm, setSearchTerm] = useState("")

  const filteredAddictions = addictions.filter(
    (addiction) =>
      addiction.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      addiction.description.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  // Animation variants for staggered list
  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 },
  }

  return (
    <div className="container max-w-6xl mx-auto px-4 py-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="space-y-8"
      >
        <div className="space-y-2">
          <h1 className="text-4xl font-bold text-white">Explore Addictions</h1>
          <p className="text-white/70">Find solutions and start your healing journey.</p>
        </div>

        <div className="relative">
          <div className="absolute inset-y-0 left-3 flex items-center pointer-events-none">
            <Search className="h-5 w-5 text-white/50" />
          </div>
          <Input
            type="search"
            placeholder="Search addictions..."
            className="pl-10 bg-white/5 border-white/10 text-white placeholder:text-white/50 focus-visible:ring-pink-500"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        <motion.div
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6"
          variants={container}
          initial="hidden"
          animate="show"
        >
          {filteredAddictions.map((addiction) => (
            <motion.div key={addiction.id} variants={item}>
              <Link href={`/dashboard/explore/${addiction.id}`}>
                <Card className="h-full hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 overflow-hidden border-0 bg-white/5 backdrop-blur-sm">
                  <CardContent className="p-0">
                    <div className={`bg-gradient-to-r ${addiction.color} p-6 text-white`}>
                      <addiction.icon className="h-8 w-8 mb-3" />
                      <h3 className="text-xl font-semibold">{addiction.name}</h3>
                    </div>
                    <div className="p-5 text-white/80">
                      <p>{addiction.description}</p>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            </motion.div>
          ))}
        </motion.div>
      </motion.div>
    </div>
  )
}
