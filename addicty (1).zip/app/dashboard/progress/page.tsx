"use client"

import { useEffect, useState } from "react"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Calendar } from "@/components/ui/calendar"
import { Badge } from "@/components/ui/badge"
import {
  CheckCircle,
  Brain,
  FlowerIcon as Butterfly,
  SpaceIcon as Alien,
  Save,
  CalendarIcon,
  PenLine,
  Trophy,
  Sparkles,
} from "lucide-react"

export default function ProgressPage() {
  const [streak, setStreak] = useState(0)
  const [lastCheckIn, setLastCheckIn] = useState<Date | null>(null)
  const [note, setNote] = useState("")
  const [checkedInToday, setCheckedInToday] = useState(false)
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date())
  const [isMounted, setIsMounted] = useState(false)

  // Load progress data from localStorage
  useEffect(() => {
    setIsMounted(true)

    const savedStreak = localStorage.getItem("addicty_streak")
    const savedLastCheckIn = localStorage.getItem("addicty_last_checkin")
    const savedNotes = localStorage.getItem("addicty_notes")

    if (savedStreak) setStreak(Number.parseInt(savedStreak))
    if (savedLastCheckIn) {
      const lastDate = new Date(savedLastCheckIn)
      setLastCheckIn(lastDate)

      // Check if user already checked in today
      const today = new Date()
      if (lastDate.toDateString() === today.toDateString()) {
        setCheckedInToday(true)
      }
    }
    if (savedNotes) setNote(savedNotes)
  }, [])

  if (!isMounted) {
    return null // Prevent hydration errors
  }

  // Handle check-in
  const handleCheckIn = () => {
    const today = new Date()

    // If already checked in today, do nothing
    if (checkedInToday) return

    // Calculate streak
    let newStreak = streak
    if (lastCheckIn) {
      const yesterday = new Date(today)
      yesterday.setDate(yesterday.getDate() - 1)

      if (lastCheckIn.toDateString() === yesterday.toDateString()) {
        // Consecutive day
        newStreak += 1
      } else if (lastCheckIn.toDateString() !== today.toDateString()) {
        // Missed a day, reset streak
        newStreak = 1
      }
    } else {
      // First check-in
      newStreak = 1
    }

    // Update state and localStorage
    setStreak(newStreak)
    setLastCheckIn(today)
    setCheckedInToday(true)

    localStorage.setItem("addicty_streak", newStreak.toString())
    localStorage.setItem("addicty_last_checkin", today.toString())
  }

  // Handle saving notes
  const handleSaveNote = () => {
    localStorage.setItem("addicty_notes", note)
    alert("Journal entry saved!")
  }

  // Get badge based on streak
  const getBadge = () => {
    if (streak >= 30) return { icon: Alien, text: "Master", color: "bg-purple-500" }
    if (streak >= 14) return { icon: Butterfly, text: "Transformer", color: "bg-blue-500" }
    return { icon: Brain, text: "Thinker", color: "bg-pink-500" }
  }

  const badge = getBadge()
  const BadgeIcon = badge.icon

  return (
    <div className="container max-w-6xl mx-auto px-4 py-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="space-y-8"
      >
        <div className="space-y-2">
          <h1 className="text-4xl font-bold text-white">Your Progress</h1>
          <p className="text-white/70">Track your journey to freedom.</p>
        </div>

        {/* Streak Card */}
        <Card className="border-0 shadow-xl bg-gradient-to-r from-pink-500 to-purple-600 overflow-hidden">
          <CardContent className="p-0">
            <div className="relative">
              {/* Background pattern */}
              <div className="absolute inset-0 opacity-10">
                <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
                  <defs>
                    <pattern id="grid" width="10" height="10" patternUnits="userSpaceOnUse">
                      <path d="M 10 0 L 0 0 0 10" fill="none" stroke="white" strokeWidth="0.5" />
                    </pattern>
                  </defs>
                  <rect width="100" height="100" fill="url(#grid)" />
                </svg>
              </div>

              <div className="p-8 md:p-10 relative z-10">
                <div className="flex flex-col md:flex-row gap-8 items-center">
                  <div className="flex-1 space-y-4">
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/20 text-white text-sm font-medium">
                      <Trophy className="h-4 w-4" />
                      <span>Your Streak</span>
                    </div>

                    <div className="space-y-2">
                      <h2 className="text-2xl md:text-3xl font-bold text-white">Day {streak} of Freedom</h2>
                      <p className="text-white/80">Keep going! Every day counts on your journey.</p>
                    </div>

                    <div className="flex flex-wrap gap-4">
                      <Button
                        onClick={handleCheckIn}
                        disabled={checkedInToday}
                        className="bg-white text-purple-600 hover:bg-white/90 disabled:bg-white/50"
                      >
                        {checkedInToday ? (
                          <span className="flex items-center gap-2">
                            <CheckCircle className="h-4 w-4" />
                            Checked in today
                          </span>
                        ) : (
                          <span className="flex items-center gap-2">
                            <Sparkles className="h-4 w-4" />
                            Check in for today
                          </span>
                        )}
                      </Button>
                    </div>
                  </div>

                  <div className="flex items-center justify-center">
                    <div className="relative">
                      <div className="w-32 h-32 rounded-full bg-white/10 backdrop-blur-md flex flex-col items-center justify-center border-4 border-white/30 shadow-lg">
                        <BadgeIcon className="h-10 w-10 text-white mb-1" />
                        <span className="text-white/90 text-sm font-medium">{badge.text}</span>
                      </div>
                      <div
                        className={`absolute -top-2 -right-2 w-8 h-8 rounded-full ${badge.color} flex items-center justify-center text-white text-xs font-bold shadow-lg`}
                      >
                        {streak}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Calendar Card */}
          <Card className="border border-white/10 bg-white/5 backdrop-blur-sm shadow-lg overflow-hidden">
            <CardHeader className="pb-3 border-b border-white/10">
              <CardTitle className="flex items-center gap-2 text-white">
                <CalendarIcon className="h-5 w-5 text-blue-500" />
                Calendar
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <Calendar
                mode="single"
                selected={selectedDate}
                onSelect={setSelectedDate}
                className="rounded-md border border-white/10 bg-white/5 text-white"
              />
            </CardContent>
          </Card>

          {/* Journal Card */}
          <Card className="border border-white/10 bg-white/5 backdrop-blur-sm shadow-lg overflow-hidden">
            <CardHeader className="pb-3 border-b border-white/10">
              <CardTitle className="flex items-center gap-2 text-white">
                <PenLine className="h-5 w-5 text-green-500" />
                Journal
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <div className="space-y-4">
                <Textarea
                  placeholder="Write your thoughts, feelings, or progress here..."
                  className="min-h-[200px] bg-white/5 border-white/10 text-white placeholder:text-white/50 focus-visible:ring-pink-500"
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                />
                <Button
                  onClick={handleSaveNote}
                  className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700"
                >
                  <Save className="mr-2 h-4 w-4" />
                  Save Journal Entry
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Badges Card */}
        <Card className="border border-white/10 bg-white/5 backdrop-blur-sm shadow-lg overflow-hidden">
          <CardHeader className="pb-3 border-b border-white/10">
            <CardTitle className="flex items-center gap-2 text-white">
              <Trophy className="h-5 w-5 text-amber-500" />
              Your Badges
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
              <div
                className={`rounded-lg p-6 flex flex-col items-center text-center ${streak >= 1 ? "bg-pink-500/20" : "bg-white/5 opacity-50"}`}
              >
                <div className="w-16 h-16 rounded-full bg-pink-500/20 flex items-center justify-center mb-3">
                  <Brain className={`h-8 w-8 ${streak >= 1 ? "text-pink-500" : "text-white/30"}`} />
                </div>
                <h3 className="text-lg font-semibold text-white mb-1">Thinker</h3>
                <p className="text-white/70 text-sm">1+ days streak</p>
                {streak >= 1 && <Badge className="mt-2 bg-pink-500 text-white border-0">Unlocked</Badge>}
              </div>

              <div
                className={`rounded-lg p-6 flex flex-col items-center text-center ${streak >= 14 ? "bg-blue-500/20" : "bg-white/5 opacity-50"}`}
              >
                <div className="w-16 h-16 rounded-full bg-blue-500/20 flex items-center justify-center mb-3">
                  <Butterfly className={`h-8 w-8 ${streak >= 14 ? "text-blue-500" : "text-white/30"}`} />
                </div>
                <h3 className="text-lg font-semibold text-white mb-1">Transformer</h3>
                <p className="text-white/70 text-sm">14+ days streak</p>
                {streak >= 14 && <Badge className="mt-2 bg-blue-500 text-white border-0">Unlocked</Badge>}
              </div>

              <div
                className={`rounded-lg p-6 flex flex-col items-center text-center ${streak >= 30 ? "bg-purple-500/20" : "bg-white/5 opacity-50"}`}
              >
                <div className="w-16 h-16 rounded-full bg-purple-500/20 flex items-center justify-center mb-3">
                  <Alien className={`h-8 w-8 ${streak >= 30 ? "text-purple-500" : "text-white/30"}`} />
                </div>
                <h3 className="text-lg font-semibold text-white mb-1">Master</h3>
                <p className="text-white/70 text-sm">30+ days streak</p>
                {streak >= 30 && <Badge className="mt-2 bg-purple-500 text-white border-0">Unlocked</Badge>}
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  )
}
