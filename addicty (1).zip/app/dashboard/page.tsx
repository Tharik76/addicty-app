"use client"

import { useEffect, useState } from "react"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { ArrowRight, Sparkles, Quote, Calendar, Compass, Brain } from "lucide-react"
import Link from "next/link"

export default function Dashboard() {
  const [userName, setUserName] = useState("")
  const [quote, setQuote] = useState("")
  const [isMounted, setIsMounted] = useState(false)
  const [streak, setStreak] = useState(0)

  // Daily quotes
  const quotes = [
    "Every day is a new opportunity to change your life.",
    "Recovery is not a race. You don't have to feel guilty if it takes you longer than you thought it would.",
    "The best time to plant a tree was 20 years ago. The second best time is now.",
    "Your addiction is not your identity.",
    "Small steps lead to big changes.",
    "You are stronger than you think.",
    "Progress, not perfection.",
  ]

  useEffect(() => {
    setIsMounted(true)

    // Get user data
    const userData = localStorage.getItem("addicty_user")
    if (userData) {
      try {
        const parsedUser = JSON.parse(userData)
        setUserName(parsedUser.name || "")
      } catch (error) {
        console.error("Failed to parse user data:", error)
      }
    }

    // Get streak data
    const savedStreak = localStorage.getItem("addicty_streak")
    if (savedStreak) setStreak(Number.parseInt(savedStreak))

    // Get random quote
    const randomIndex = Math.floor(Math.random() * quotes.length)
    setQuote(quotes[randomIndex])
  }, [])

  if (!isMounted) {
    return null // Prevent hydration errors
  }

  return (
    <div className="container max-w-6xl mx-auto px-4 py-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="space-y-8"
      >
        <div className="space-y-2">
          <h1 className="text-4xl font-bold text-white">Welcome back, {userName}!</h1>
          <p className="text-white/70">Your journey to freedom continues today.</p>
        </div>

        {/* Hero Card */}
        <Card className="overflow-hidden border-0 shadow-xl bg-gradient-to-br from-pink-500 to-purple-600">
          <CardContent className="p-0">
            <div className="relative">
              {/* Background pattern */}
              <div className="absolute inset-0 opacity-10">
                <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
                  <defs>
                    <pattern id="grid" width="10" height="10" patternUnits="userSpaceOnUse">
                      <path d="M 10 0 L 0 0 0 10" fill="none" stroke="white" strokeWidth="0.5" />
                    </pattern>
                  </defs>
                  <rect width="100" height="100" fill="url(#grid)" />
                </svg>
              </div>

              <div className="p-8 md:p-10 relative z-10">
                <div className="flex flex-col md:flex-row gap-8 items-center">
                  <div className="flex-1 space-y-6">
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/20 text-white text-sm font-medium">
                      <Sparkles className="h-4 w-4" />
                      <span>Daily Motivation</span>
                    </div>

                    <div className="space-y-2">
                      <h2 className="text-2xl md:text-3xl font-bold text-white">Ready to continue your journey?</h2>
                      <p className="text-white/80 text-lg italic">"{quote}"</p>
                    </div>

                    <div className="flex flex-wrap gap-4">
                      <Button asChild size="lg" className="bg-white text-purple-600 hover:bg-white/90">
                        <Link href="/dashboard/explore">
                          Start Healing <ArrowRight className="ml-2 h-4 w-4" />
                        </Link>
                      </Button>

                      <Button
                        asChild
                        variant="outline"
                        size="lg"
                        className="border-white text-white hover:bg-white hover:text-purple-600"
                      >
                        <Link href="/dashboard/progress">View Progress</Link>
                      </Button>
                    </div>
                  </div>

                  <div className="flex items-center justify-center">
                    <div className="w-40 h-40 rounded-full bg-white/10 backdrop-blur-md flex flex-col items-center justify-center border-4 border-white/30 shadow-lg">
                      <span className="text-4xl font-bold text-white">{streak}</span>
                      <span className="text-white/80 text-sm">Day{streak !== 1 ? "s" : ""} Streak</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Feature Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="bg-gradient-to-br from-blue-500 to-cyan-600 border-0 shadow-lg overflow-hidden group hover:shadow-xl transition-all duration-300">
            <CardContent className="p-6">
              <div className="flex flex-col h-full">
                <div className="mb-4">
                  <div className="w-12 h-12 rounded-lg bg-white/20 flex items-center justify-center mb-4">
                    <Compass className="h-6 w-6 text-white" />
                  </div>
                  <h3 className="text-xl font-semibold text-white mb-2">Explore Addictions</h3>
                  <p className="text-white/80 mb-4">
                    Find solutions for various addictions and start your healing journey.
                  </p>
                </div>
                <Button
                  asChild
                  variant="ghost"
                  className="mt-auto text-white hover:bg-white/20 group-hover:translate-x-1 transition-transform"
                >
                  <Link href="/dashboard/explore" className="flex items-center">
                    Explore Now
                    <ArrowRight className="ml-2 h-4 w-4 group-hover:ml-3 transition-all" />
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-amber-500 to-orange-600 border-0 shadow-lg overflow-hidden group hover:shadow-xl transition-all duration-300">
            <CardContent className="p-6">
              <div className="flex flex-col h-full">
                <div className="mb-4">
                  <div className="w-12 h-12 rounded-lg bg-white/20 flex items-center justify-center mb-4">
                    <Calendar className="h-6 w-6 text-white" />
                  </div>
                  <h3 className="text-xl font-semibold text-white mb-2">Track Progress</h3>
                  <p className="text-white/80 mb-4">
                    Monitor your journey to freedom with daily check-ins and streaks.
                  </p>
                </div>
                <Button
                  asChild
                  variant="ghost"
                  className="mt-auto text-white hover:bg-white/20 group-hover:translate-x-1 transition-transform"
                >
                  <Link href="/dashboard/progress" className="flex items-center">
                    View Progress
                    <ArrowRight className="ml-2 h-4 w-4 group-hover:ml-3 transition-all" />
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-emerald-500 to-green-600 border-0 shadow-lg overflow-hidden group hover:shadow-xl transition-all duration-300">
            <CardContent className="p-6">
              <div className="flex flex-col h-full">
                <div className="mb-4">
                  <div className="w-12 h-12 rounded-lg bg-white/20 flex items-center justify-center mb-4">
                    <Brain className="h-6 w-6 text-white" />
                  </div>
                  <h3 className="text-xl font-semibold text-white mb-2">Learn More</h3>
                  <p className="text-white/80 mb-4">Discover the science behind addiction and recovery strategies.</p>
                </div>
                <Button
                  asChild
                  variant="ghost"
                  className="mt-auto text-white hover:bg-white/20 group-hover:translate-x-1 transition-transform"
                >
                  <Link href="/dashboard/about" className="flex items-center">
                    About Addicty
                    <ArrowRight className="ml-2 h-4 w-4 group-hover:ml-3 transition-all" />
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Quote of the Day */}
        <Card className="border border-white/10 bg-white/5 backdrop-blur-sm shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-pink-500 to-purple-600 flex items-center justify-center flex-shrink-0">
                <Quote className="h-5 w-5 text-white" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-white mb-2">Quote of the Day</h3>
                <p className="text-white/80 italic">"{quote}"</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  )
}
