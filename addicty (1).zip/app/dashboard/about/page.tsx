"use client"

import { motion } from "framer-motion"
import { Card, CardContent } from "@/components/ui/card"
import { Brain, Heart, Sparkles, Target } from "lucide-react"

export default function AboutPage() {
  return (
    <div className="container max-w-6xl mx-auto px-4 py-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="space-y-8"
      >
        <div className="space-y-2">
          <h1 className="text-4xl font-bold text-white">About Addicty</h1>
          <p className="text-white/70">Your healing partner in the journey to freedom.</p>
        </div>

        {/* Hero Card */}
        <Card className="border-0 shadow-xl bg-gradient-to-r from-blue-600 to-purple-600 overflow-hidden">
          <CardContent className="p-0">
            <div className="relative">
              {/* Background pattern */}
              <div className="absolute inset-0 opacity-10">
                <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
                  <defs>
                    <pattern id="grid" width="10" height="10" patternUnits="userSpaceOnUse">
                      <path d="M 10 0 L 0 0 0 10" fill="none" stroke="white" strokeWidth="0.5" />
                    </pattern>
                  </defs>
                  <rect width="100" height="100" fill="url(#grid)" />
                </svg>
              </div>

              <div className="p-8 md:p-10 relative z-10 text-center">
                <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">Addicty</h2>
                <p className="text-xl text-white/90 max-w-2xl mx-auto">Escape addiction. Reclaim your freedom 🧠🦋👾</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card className="border border-white/10 bg-white/5 backdrop-blur-sm shadow-lg overflow-hidden">
            <CardContent className="p-6">
              <div className="flex flex-col h-full">
                <div className="w-12 h-12 rounded-lg bg-pink-500/20 flex items-center justify-center mb-4">
                  <Target className="h-6 w-6 text-pink-500" />
                </div>
                <h3 className="text-xl font-semibold text-white mb-3">Our Mission</h3>
                <p className="text-white/80">
                  Addicty is your healing partner. We help you escape addiction, one step at a time. Our mission is to
                  provide accessible, practical tools and resources to help people overcome various forms of addiction
                  and reclaim control of their lives.
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="border border-white/10 bg-white/5 backdrop-blur-sm shadow-lg overflow-hidden">
            <CardContent className="p-6">
              <div className="flex flex-col h-full">
                <div className="w-12 h-12 rounded-lg bg-blue-500/20 flex items-center justify-center mb-4">
                  <Sparkles className="h-6 w-6 text-blue-500" />
                </div>
                <h3 className="text-xl font-semibold text-white mb-3">Our Vision</h3>
                <p className="text-white/80">
                  We envision a world where people have the knowledge, support, and tools they need to break free from
                  addictive behaviors and live healthier, more fulfilling lives. We believe that with the right guidance
                  and community support, anyone can overcome addiction and transform their life.
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="border border-white/10 bg-white/5 backdrop-blur-sm shadow-lg overflow-hidden">
            <CardContent className="p-6">
              <div className="flex flex-col h-full">
                <div className="w-12 h-12 rounded-lg bg-amber-500/20 flex items-center justify-center mb-4">
                  <Heart className="h-6 w-6 text-amber-500" />
                </div>
                <h3 className="text-xl font-semibold text-white mb-3">Why It Matters</h3>
                <p className="text-white/80">
                  Addiction affects millions of people worldwide, yet many struggle in silence due to stigma, lack of
                  resources, or not knowing where to turn for help. Addicty aims to break down these barriers by
                  providing a private, supportive space where users can learn about their addictions, track their
                  progress, and find practical solutions.
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="border border-white/10 bg-white/5 backdrop-blur-sm shadow-lg overflow-hidden">
            <CardContent className="p-6">
              <div className="flex flex-col h-full">
                <div className="w-12 h-12 rounded-lg bg-green-500/20 flex items-center justify-center mb-4">
                  <Brain className="h-6 w-6 text-green-500" />
                </div>
                <h3 className="text-xl font-semibold text-white mb-3">Our Approach</h3>
                <p className="text-white/80">
                  We take a holistic approach to addiction recovery, recognizing that each person's journey is unique.
                  Our app combines educational resources, practical tools, progress tracking, and motivational content
                  to support users at every stage of their recovery journey.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Quote Card */}
        <Card className="border border-white/10 bg-white/5 backdrop-blur-sm shadow-lg overflow-hidden">
          <CardContent className="p-8 text-center">
            <blockquote className="text-xl md:text-2xl italic text-white/90 max-w-3xl mx-auto">
              "The journey of a thousand miles begins with a single step."
            </blockquote>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  )
}
